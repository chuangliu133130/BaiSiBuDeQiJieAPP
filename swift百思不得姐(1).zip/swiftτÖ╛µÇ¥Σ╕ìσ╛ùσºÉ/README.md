# 百思不得姐 swift版
这几天阅读了[《The Swift Programming Language》2.0中文手册](http://www.swiftvip.cn/guide/index.html),刚好看到百思不得姐的API，就试着去用swift写了一下，并没有完成太多功能。  

# Demo Project
---

![demo](http://7xpk2w.com1.z0.glb.clouddn.com/baisi.gif)

# 已完成功能

* 精华和最新模块的搭建
* 登陆界面做了简单的动画

# 待完成功能

* 发布界面的搭建
* 换肤功能的实现
* 视频和音频的播放

### *祝大家新的一年程序无Bug,产品不改需求，顺便来个star*
